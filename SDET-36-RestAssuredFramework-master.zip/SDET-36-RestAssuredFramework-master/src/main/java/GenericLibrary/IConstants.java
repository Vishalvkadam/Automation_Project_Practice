package GenericLibrary;

public interface IConstants {

	String dbURL = "jdbc:mysql://localhost:3306/projects";
	String dbUserName = "root";
	String dbPassword = "root";
	
	String appUserName = "rmgyantra";
	String appPassword = "rmgy@9999";
}
