package genericLibrary;

/**
 * This interfcae consists of all the constants
 * @author Chaitra M
 *
 */
public interface ConstantLibrary {
	
	String dbURL = "jdbc:mysql://localhost:3306/projects";
	String dbUsername = "root";
	String dbPassword = "root";
	
	String apiUsername = "rmgyantra";
	String apiPassword = "rmgy@9999";

}
