package Programs;

public class Sample {

	
	public static void run()
	{
		System.out.println("static ");
	}
	
	public static void main(String[] args) 
	{
		
	     System.out.println("Hai hello");
	     run();
	}

}
