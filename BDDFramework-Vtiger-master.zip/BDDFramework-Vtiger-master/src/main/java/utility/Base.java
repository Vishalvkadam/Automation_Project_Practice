package utility;

import org.openqa.selenium.WebDriver;

public class Base {
	
	public WebDriver driver;

}
