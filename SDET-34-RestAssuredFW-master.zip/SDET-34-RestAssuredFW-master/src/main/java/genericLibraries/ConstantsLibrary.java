package genericLibraries;

public interface ConstantsLibrary {
	
	String dbURL = "jdbc:mysql://localhost:3306/Projects";
	String dbUsername = "root";
	String dbPassword = "root";

}
