package com.crm.qa.Pages;

import com.crm.qa.BaseClass.TestBase;

public class DealsPage extends TestBase
{

}
