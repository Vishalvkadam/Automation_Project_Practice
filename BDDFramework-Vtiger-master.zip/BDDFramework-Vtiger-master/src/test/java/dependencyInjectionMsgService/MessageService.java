package dependencyInjectionMsgService;

public interface MessageService {
	
	void sendMessage(String msg, String recipient);

}
