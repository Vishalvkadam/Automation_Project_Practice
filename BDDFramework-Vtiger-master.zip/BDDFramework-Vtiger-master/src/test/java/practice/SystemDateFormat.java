package practice;

import utility.WebDriverUtility;

public class SystemDateFormat {
	
	public static void main(String[] args) {
		
		WebDriverUtility w=new WebDriverUtility();
		System.out.println(w.sysDate());
	}

}
