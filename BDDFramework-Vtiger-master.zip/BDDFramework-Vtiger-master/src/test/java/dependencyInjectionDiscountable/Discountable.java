package dependencyInjectionDiscountable;

public interface Discountable {
	
	void getDiscount(String company, String percentage);

}
