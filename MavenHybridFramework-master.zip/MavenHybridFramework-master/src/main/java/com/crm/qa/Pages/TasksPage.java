package com.crm.qa.Pages;

import com.crm.qa.BaseClass.TestBase;

public class TasksPage extends TestBase
{

}
