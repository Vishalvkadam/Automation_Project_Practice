package com.crm.OrgTests;

import org.testng.annotations.Test;

public class CreateOrgTest {
	
	@Test
	public void createOrgTest()
	{
		System.out.println("User 1 created organization");
		
		System.out.println("user 2 modified organization");
		
		System.out.println("User 2 update organization");
		System.out.println("Hi");

		System.out.println("User 1 deleted Organization");//user 1
		
		
		System.out.println("User 2: Branch 1 commit");


		


	}

}
